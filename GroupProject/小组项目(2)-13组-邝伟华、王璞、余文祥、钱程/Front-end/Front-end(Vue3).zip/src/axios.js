import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://192.168.174.214:8000', // 后端服务的地址
  headers: {
    'Content-Type': 'application/json',
  },
});

export default apiClient;
