<template>
  <el-aside width="200px" class="sidebar">
    <el-button type="primary" class="new-conversation">New Conversation</el-button>
  </el-aside>
</template>

<script>
export default {
  name: 'ChatSidebar',
};
</script>

<style scoped>
.sidebar {
  background-color: #f5f5f5;
  border-right: 1px solid #dcdfe6;
  padding: 10px;
}

.new-conversation {
  width: 100%;
}
</style>
