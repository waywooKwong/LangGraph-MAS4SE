import { createRouter, createWebHistory } from 'vue-router';
import ChatView from '@/views/ChatView.vue';

const routes = [
  {
    path: '/',
    name: 'ChatView',
    component: ChatView,
  },
];

const router = createRouter({
  history: createWebHistory(), // 不使用 BASE_URL
  routes,
});

export default router;
